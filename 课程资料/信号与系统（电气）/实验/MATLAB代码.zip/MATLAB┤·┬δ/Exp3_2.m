%% 2

a = [1, 0, 1];
b = [1,2,-3,3,3,2];
sys = tf(a, b);
pzmap(sys);
pole = pole(sys);
zero = zero(sys);

