a = [1, 0.4, -0.12];
b = [1, 2];
N = 30;
f = ones(1,N);
k = 0:1:N-1;
y = filter(b,a,f);
stem(k,y);
xlabel('k');
title('系统零状态响应y(k)');
