den = [1 2^(1/2) 1];
num = [1 0 0];
subplot(2,1,1);
impz(num,den,-10:30);
subplot(2,1,2);
p = roots(den);
z = roots(num);
zplane(z,p);
title('零极点分布图');
