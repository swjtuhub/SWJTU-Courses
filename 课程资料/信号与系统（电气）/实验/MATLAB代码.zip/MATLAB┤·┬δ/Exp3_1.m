%% 拉普拉斯变换的MATLAB实现

% 1.1
syms t;
f = cos(2*t)*sin(3*t)*heaviside(t);
L = laplace(f);
display(L);

% 1.2
syms s;
H1 = ((s+1)*(s+4))/(s*(s+2)*(s+3));
h1 = ilaplace(H1);
display(h1);
H2 = (s^3+5*s^2+9*s+7)/(s^2+3*s+2);
h2 = ilaplace(H2);
display(h2);

