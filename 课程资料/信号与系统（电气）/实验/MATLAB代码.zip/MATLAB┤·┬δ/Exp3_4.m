%% 4

syms t s;
f = (-t+1)*(heaviside(t)-heaviside(t-2))-(heaviside(t-2)-heaviside(t-3));
subplot(2, 1, 1);
fplot(f);
axis([0, 10, -1.5, 1.5]);
title('输入信号');
grid on;
subplot(2, 1, 2);
F = laplace(f);
H = 1/(s^2+5*s+4);
Y = F*H;
y = ilaplace(Y);
fplot(y);
axis([0, 10, -0.2, 0.1]);
title('零状态响应');
grid on;

