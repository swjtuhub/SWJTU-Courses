% F3_14.m

close all
clear
clc

I1=imread('lena.bmp');
I2=imrotate(I1,-30);
I3=imrotate(I1,30);

subplot(1,3,1),imshow(I1),xlabel('(a) ԭʼͼ��');
subplot(1,3,2),imshow(I2),xlabel('(b) ˳ʱ����ת');
subplot(1,3,3),imshow(I3),xlabel('(c) ��ʱ����ת');
