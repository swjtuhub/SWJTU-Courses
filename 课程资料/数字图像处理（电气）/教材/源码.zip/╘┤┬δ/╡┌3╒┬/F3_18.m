% F3_18.m

close all
clear
clc

I=imread('lena.bmp');
udata = [0 1];
vdata = [0 1]
T = [0 0
       1 0
       1 1
       0 1]
T1 = [-4  2
         -8 -3
          1 -8
          6  6]
T2 = [6  6
         1 -8
        -8 -3
        -4  2]
tform = maketform('projective',T,T1);
[B1,xdata,ydata]= imtransform(I,tform,'bicubic','udata',udata,'vdata',vdata,'size',size(I),'fill',255);

tform = maketform('projective',T,T2);
[B2,xdata,ydata]= imtransform(I,tform,'bicubic','udata',udata,'vdata',vdata,'size',size(I),'fill',255);

subplot(1,3,1),imshow(I),axis on,xlabel('(a) ԭʼͼ��');
subplot(1,3,2),imshow(B1),axis on,xlabel('(b) ͸��ͼ��1');
subplot(1,3,3),imshow(B2),axis on,xlabel('(c) ͸��ͼ��2');
