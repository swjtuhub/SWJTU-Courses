% F3_30.m

close all
clear
clc

x=-6.3:0.01:6.3;
y=sin(x)./x;
subplot(1,2,1),plot(x,y);hold on;
line([-8 8],[0 0]);hold on;

x1=-1:0.01:1;
s1=1-2.*abs(x1).*abs(x1)+abs(x1).*abs(x1).*abs(x1);
subplot(1,2,1),plot(x1,s1);hold on;

x2=-2:0.01:-1;
s2=4-8.*abs(x2)+5.*abs(x2).*abs(x2)-abs(x2).*abs(x2).*abs(x2);
subplot(1,2,1),plot(x2,s2);hold on;

x3=1:0.01:2;
s3=4-8.*abs(x3)+5.*abs(x3).*abs(x3)-abs(x3).*abs(x3).*abs(x3);
subplot(1,2,1),plot(x3,s3),xlabel('(a) y=sin(x)/x��˫���β�ֵ�����Ա�');hold on;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

x1=-1:0.01:1;
s1=1-2.*abs(x1).*abs(x1)+abs(x1).*abs(x1).*abs(x1);
subplot(1,2,2),plot(x1,s1,'k');hold on;

x2=-2:0.01:-1;
s2=4-8.*abs(x2)+5.*abs(x2).*abs(x2)-abs(x2).*abs(x2).*abs(x2);
subplot(1,2,2),plot(x2,s2,'k');hold on;

x3=1:0.01:2;
s3=4-8.*abs(x3)+5.*abs(x3).*abs(x3)-abs(x3).*abs(x3).*abs(x3);
subplot(1,2,2),plot(x3,s3,'k'),xlabel('(b) ˫���β�ֵ����');hold on;
plot([-2.5 2.5],[0 0],'k');plot([0 0],[-0.2 1.1],'k');
% text(-2,-0.03,'-2');text(-1,-0.03,'-1');text(0.05,-0.03,'0');text(0.95,-0.03,'1');text(2,-0.03,'2');
% text(-0.1,1.02,'1');text(2.4,0,'>');text(-0.04,1.095,'\Lambda');
