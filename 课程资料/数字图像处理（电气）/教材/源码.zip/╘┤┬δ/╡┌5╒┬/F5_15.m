% F5_15.m

close all
clear
clc

I=[0 0 0 80 0 0 0 240 240 240 160 80 0 0 0 0];
uint8I=uint8(I);
subplot(2,2,1),imshow(uint8I),xlabel('(b) ԭʼͼ��');
subplot(2,2,2),plot(I,'.-'),axis([0 17 0 250]),xlabel('(c) ԭʼͼ���άʾ��ͼ');

J=medfilt2(uint8I,[1,3]);
subplot(2,2,3),plot(J,'.-'),axis([0 17 0 250]),xlabel('(d) �˲�ͼ��');

uint8J=uint8(J);
subplot(2,2,4),imshow(uint8J),xlabel('(f) �˲�ͼ���άʾ��ͼ');
