% F5_22.m

close all
clear
clc

I=[0   30  60
   90  120 150
   180 210 240];
uint8I=uint8(I)
subplot(2,3,1),imshow(uint8I),xlabel('(a) ԭʼͼ��');

mask=[0 1 0
      1 0 1
      0 1 0];
uint8mask=uint8(mask)
subplot(2,3,2),imshow(~~uint8mask),xlabel('(b) ģ��ͼ��');

K1=ordfilt2(I,1,mask);
uint8K1=uint8(K1)
subplot(2,3,3),imshow(uint8K1),xlabel('(c) ��Сֵ�˲�ͼ��');

K2=ordfilt2(I,2,mask);
uint8K2=uint8(K2)
subplot(2,3,4),imshow(uint8K2),xlabel('(d) ��2Сֵ�˲�ͼ��');

K3=ordfilt2(I,3,mask);
uint8K3=uint8(K3)
subplot(2,3,5),imshow(uint8K3),xlabel('(e) ��3Сֵ�˲�ͼ��');

K4=ordfilt2(I,4,mask);
uint8K4=uint8(K4)
subplot(2,3,6),imshow(uint8K4),xlabel('(f) ���ֵ�˲�ͼ��');
