% F5_23.m

close all
clear
clc

I=imread('eight.tif');
subplot(2,3,1),imshow(I),xlabel('(a) ԭʼͼ��');
% imwrite(I,'.\F5_23a.bmp');

J=imnoise(I,'salt & pepper',0.1);
subplot(2,3,2),imshow(J),xlabel('(b) ��������ͼ��');
% imwrite(J,'.\F5_23b.bmp');

mask=[0 1 0
      1 1 1
      0 1 0];
subplot(2,3,3),imshow(mask),xlabel('(c) �˲�ģ��');

K1=ordfilt2(J,3,mask);
uint8K1=uint8(K1);
subplot(2,3,4),imshow(uint8K1),xlabel('(d) ��ֵ�˲�ͼ��');
% imwrite(K1,'.\F5_23d.bmp');

K2=ordfilt2(J,1,mask);
uint8K2=uint8(K2);
subplot(2,3,5),imshow(uint8K2),xlabel('(e) ��Сֵ�˲�ͼ��');
% imwrite(K2,'.\F5_23e.bmp');

K3=ordfilt2(J,5,mask);
uint8K3=uint8(K3);
subplot(2,3,6),imshow(uint8K3),xlabel('(f) ���ֵ�˲�ͼ��');
% imwrite(K3,'.\F5_23f.bmp');
