% F1_7.m

close all
clear
clc

I1=imread('F1_7_256.bmp');
subplot(1,2,1),imshow(I1),xlabel('(a) 256ɫ�Ҷ�ͼ��');

I2=imread('F1_7_24b.bmp');
subplot(1,2,2),imshow(I2),xlabel('(b) 24λ���ɫͼ��');
