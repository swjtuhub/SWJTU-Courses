% F6_19.m

close all
clear
clc

N=4;    %N=8;

for u=0:N-1
    for v=0:N-1
        subplot(N,N,u*N+(v+1)),imshow(F6_19_HDCT(u,v,N),[]);
    end
end
