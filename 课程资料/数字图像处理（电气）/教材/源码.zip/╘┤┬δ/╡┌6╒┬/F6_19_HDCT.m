function H=HDCT(u,v,N)
%��ɢ����Ҷ�任�ĺ˺���:h(x,y,u,v)=a(u)*a(v)*cos((2*x+1)*u*pi/(2*N))*cos((2*y+1)*v*pi/(2*N))

if u==0
    au=sqrt(1/N);
else
    au=sqrt(2/N);
end

if v==0
    av=sqrt(1/N);
else
    av=sqrt(2/N);
end

H=zeros(N);
for x=0:N-1
    for y=0:N-1
        H(x+1,y+1)=au*av*cos((2*x+1)*u*pi/(2*N))*cos((2*y+1)*v*pi/(2*N));
    end
end
