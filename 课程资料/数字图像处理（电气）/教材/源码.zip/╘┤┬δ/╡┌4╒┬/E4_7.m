% E4_7.m

close all
clear
clc

X=uint8([50  50  50
         50  50  50])
Y=uint8([1  2  3
         4  5  6])
Z=immultiply(X,Y)
