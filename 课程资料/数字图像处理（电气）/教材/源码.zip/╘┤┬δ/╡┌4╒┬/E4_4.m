% E4_4.m

close all
clear
clc

X=uint8([255 0   75
         44  255 100])
Y=uint8([50  50  50
         50  50  50])
Z=imsubtract(X,Y)
