% F4_23.m

close all
clear
clc

% -------------------------------------------------------------------------
% ԭʼͼ������
Pic=imread('rice.png');
figure,imshow(Pic);
pause

% -------------------------------------------------------------------------
% ԭʼͼ�����ݶ�ֵ��
Pic=im2bw(Pic);
figure,imshow(Pic);
pause

% -------------------------------------------------------------------------
% �����߼�����ı�Ե���
PicSize=size(Pic);
row=PicSize(1,1);    %����
col=PicSize(1,2);    %����

% -------------------------------------------------------------------------
% ��1��: ����
PicLA=Pic;
figure,subplot(4,4,1),imshow(PicLA),xlabel('(a)'),ylabel('����');

PicLB=PicLA;
PicLB(:,1)=[];
PicLB=[PicLB ones(row,1)];
subplot(4,4,2),imshow(PicLB),xlabel('(b)');

PicLC=PicLA | PicLB;
subplot(4,4,3),imshow(PicLC),xlabel('(c)');

PicLD=xor(PicLA,PicLC);
subplot(4,4,4),imshow(PicLD),xlabel('(d)');

% -------------------------------------------------------------------------
% ��2��: ����
PicRA=Pic;
subplot(4,4,5),imshow(PicRA),xlabel('(a)'),ylabel('����');

PicRB=PicRA;
PicRB(:,col)=[];
PicRB=[ones(row,1) PicRB];
subplot(4,4,6),imshow(PicRB),xlabel('(b)');

PicRC=PicRA | PicRB;
subplot(4,4,7),imshow(PicRC),xlabel('(c)');

PicRD=xor(PicRA,PicRC);
subplot(4,4,8),imshow(PicRD),xlabel('(d)');

% -------------------------------------------------------------------------
% ��3��: ����
PicUA=Pic;
subplot(4,4,9),imshow(PicUA),xlabel('(a)'),ylabel('����');

PicUB=PicUA;
PicUB(1,:)=[];
PicUB=[PicUB;ones(1,col)];
subplot(4,4,10),imshow(PicUB),xlabel('(b)');

PicUC=PicUA | PicUB;
subplot(4,4,11),imshow(PicUC),xlabel('(c)');

PicUD=xor(PicUA,PicUC);
subplot(4,4,12),imshow(PicUD),xlabel('(d)');

% -------------------------------------------------------------------------
% ��4��: ����
PicDA=Pic;
subplot(4,4,13),imshow(PicDA),xlabel('(a)'),ylabel('����');

PicDB=PicDA;
PicDB(row,:)=[];
PicDB=[ones(1,col);PicDB];
subplot(4,4,14),imshow(PicDB),xlabel('(b)');

PicDC=PicDA | PicDB;
subplot(4,4,15),imshow(PicDC),xlabel('(c)');

PicDD=xor(PicDA,PicDC);
subplot(4,4,16),imshow(PicDD),xlabel('(d)');

% -------------------------------------------------------------------------
% ��5��: �����
pause;
figure,imshow(PicLD | PicRD | PicUD | PicDD);
