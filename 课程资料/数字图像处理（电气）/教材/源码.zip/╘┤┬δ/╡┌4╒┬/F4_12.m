% F4_12.m

close all
clear
clc

I1=imread('A.bmp');
I2=imread('B.bmp');

I3=rgb2gray(I1);
I4=rgb2gray(I2);
I5=imdivide(I3,I4);

I6=im2bw(I1);
I7=im2bw(I2);
I8=imdivide(I6,I7);

subplot(2,2,1),imshow(I3),xlabel('(a) ͼA');
subplot(2,2,2),imshow(I4),xlabel('(b) ͼB');
subplot(2,2,3),imshow(I5),xlabel('(c) �Ҷ�ͼ��A/B');
subplot(2,2,4),imshow(I8),xlabel('(d) ��ֵͼ��A/B');

% imwrite(I5,'.\F4_12c.bmp');
% imwrite(I8,'.\F4_12d.bmp');
