% E4_17.m

close all
clear
clc

X=uint8([0  1  2  3])
Y=~X
