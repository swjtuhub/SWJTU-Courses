% E4_10.m

close all
clear
clc

X=uint8([0  0   50
         50  50  50])
Y=uint8([0  1   0
         2  3   4])
Z=imdivide(X,Y)
