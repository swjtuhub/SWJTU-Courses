% F4_3.m

close all
clear
clc

I1=imread('rice.png');
I2=imread('cameraman.tif');
I3=imadd(I1,I2);

subplot(1,3,1),imshow(I1),xlabel('A');
subplot(1,3,2),imshow(I2),xlabel('B');
subplot(1,3,3),imshow(I3),xlabel('A+B');
