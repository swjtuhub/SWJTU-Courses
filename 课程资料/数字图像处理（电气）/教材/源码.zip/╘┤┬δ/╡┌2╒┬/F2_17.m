% F2_17.m

close all
clear
clc

I1=imread('F2_14a.png');
imwrite(I1, 'F2_17a.png', 'Bitdepth', 8);   % Bitdepth = 8

I2=imread('F2_14b.png');
imwrite(I2, 'F2_17b.png', 'Bitdepth', 4);   % Bitdepth = 4

I3=imread('F2_14c.png');
imwrite(I3, 'F2_17c.png', 'Bitdepth', 2);   % Bitdepth = 2

I4=imread('F2_14d.png');
Black = find( im2bw(I4)==0 );
White = find( im2bw(I4)==1 );
I4(Black)=0;
I4(White)=170;
imwrite(I4, 'F2_17d.png');   % Bitdepth = 8 ���������� Bitdepth = 1

%----�ߴ��һ��------------------------------------

J1=imread('F2_17a.png');    % 256*256
subplot(2,2,1),imshow(J1),xlabel('(a) 256��256,256���Ҷ�');

J2=imread('F2_17b.png');     % 128*128
J2=imresize(J2, 2,'nearest');    % 256*256
subplot(2,2,2),imshow(J2),xlabel('(b) 128��128,16���Ҷ�');

J3=imread('F2_17c.png');     % 64*64
J3=imresize(J3, 4,'nearest');    % 256*256
subplot(2,2,3),imshow(J3),xlabel('(c) 64��64,4���Ҷ�');

J4=imread('F2_17d.png');     % 32*32
J4=imresize(J4,8,'nearest');    % 256*256
subplot(2,2,4),imshow(J4),xlabel('(d) 32��32,2���Ҷ�');

imwrite(J1, 'F2_17a.png');
imwrite(J2, 'F2_17b.png');
imwrite(J3, 'F2_17c.png');
imwrite(J4, 'F2_17d.png');
