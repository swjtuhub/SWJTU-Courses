% E2_18b.m

close all;
clear;
clc

imfinfo('F2_18a.bmp')

I=imread('F2_18a.bmp')
imshow(I);
