% F2_19b.m

close all;
clear;
clc

imfinfo('F2_19a.bmp')

I=imread('F2_19a.bmp')
imshow(I);
