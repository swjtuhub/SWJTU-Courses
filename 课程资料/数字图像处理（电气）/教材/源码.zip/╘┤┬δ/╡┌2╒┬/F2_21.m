% F2_21.m

close all;
clear;
clc

imfinfo('F2_21a.bmp')
imfinfo('F2_21b.bmp')
imfinfo('F2_21c.bmp')
