% F2_20b.m

close all;
clear;
clc

imfinfo('F2_20a.bmp')

I=imread('F2_20a.bmp')
imshow(I);