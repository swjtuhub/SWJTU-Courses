% F2_14.m

close all
clear
clc

J=imread('concordorthophoto.png');    % 2215*2956
I1=imresize(J,[256,256]);    % 256*256
subplot(2,2,1),imshow(I1),xlabel('(a) 256��256,256���Ҷ�');

I2=imresize(I1, 0.5,'nearest');    % 128*128
subplot(2,2,2),imshow(I2),xlabel('(b) 128��128,256���Ҷ�');

I3=imresize(I2, 0.5,'nearest');    % 64*64
subplot(2,2,3),imshow(I3),xlabel('(c) 64��64,256���Ҷ�');

I4=imresize(I3, 0.5,'nearest');    % 32*32
subplot(2,2,4),imshow(I4),xlabel('(d) 32��32,256���Ҷ�');

 imwrite(I1, 'F2_14a.png');
 imwrite(I2, 'F2_14b.png');
 imwrite(I3, 'F2_14c.png');
 imwrite(I4, 'F2_14d.png');
