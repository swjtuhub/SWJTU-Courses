% F2_16.m

close all
clear
clc

J=imread('concordorthophoto.png');    % 2215*2956
I=imresize(J,[256,256]);    % 256*256

imwrite(I, 'F2_16a.png', 'Bitdepth', 8);   % Bitdepth = 8
imwrite(I, 'F2_16b.png', 'Bitdepth', 4);   % Bitdepth = 4
imwrite(I, 'F2_16c.png', 'Bitdepth', 2);   % Bitdepth = 2

Black = find( im2bw(I)==0 );
White = find( im2bw(I)==1 );
I(Black)=0;
I(White)=170;

imwrite(I, 'F2_16d.png');   % Bitdepth = 8 ���������� Bitdepth = 1

I1=imread('F2_16a.png');
I2=imread('F2_16b.png');
I3=imread('F2_16c.png');
I4=imread('F2_16d.png');
subplot(2,2,1),imshow(I1),xlabel('(a) 256��256,256���Ҷ�');
subplot(2,2,2),imshow(I2),xlabel('(b) 256��256,16���Ҷ�');
subplot(2,2,3),imshow(I3),xlabel('(c) 256��256,4���Ҷ�');
subplot(2,2,4),imshow(I4),xlabel('(d) 256��256,2���Ҷ�');
