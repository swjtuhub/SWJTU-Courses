% F7_25.m

close all
clear
clc

uu=-10:0.1:10;
[u,v]=meshgrid(uu);
n=2;
D0=3;

H3=1-exp(-(u.^2+v.^2)/(2*D0^2));
subplot(1,2,1),plot(uu,H3),xlabel('\itu'),ylabel('{\ith}({\itu})'),title('(a) ����ͼ'),grid on;
subplot(1,2,2),mesh(u,v,H3),xlabel('\itu'),ylabel('\itv'),zlabel('{\ith}({\itu},{\itv})'),title('(b) ��άͼ');

