% F7_21.m

close all
clear
clc

uu=-10:0.1:10;
[u,v]=meshgrid(uu);
n=2;
D0=3;

H1=exp(-(D0./((u.^2+v.^2).^(1/2))).^n);
subplot(2,2,1),plot(uu,H1),xlabel('\itu'),ylabel('{\ith}({\itu})'),title('(a) ����ͼ'),grid on;
subplot(2,2,2),mesh(u,v,H1),xlabel('\itu'),ylabel('\itv'),zlabel('{\ith}({\itu},{\itv})'),title('(b) ��άͼ');

H2=1-exp(-(((u.^2+v.^2).^(1/2))./D0).^n);
subplot(2,2,3),plot(uu,H2),xlabel('\itu'),ylabel('{\ith}({\itu})'),title('(c) ����ͼ'),grid on;
subplot(2,2,4),mesh(u,v,H2),xlabel('\itu'),ylabel('\itv'),zlabel('{\ith}({\itu},{\itv})'),title('(d) ��άͼ');

