% F7_2.m

close all
clear
clc

f1xy=imread('eight.tif');
subplot(2,3,1),imshow(f1xy),xlabel('(a) ԭʼͼ��');
% imwrite(f1xy,'.\F7_2a.bmp');

f2xy=imnoise(f1xy,'salt & pepper',0.05);
subplot(2,3,2),imshow(f2xy),xlabel('(b) ����ͼ��');
% imwrite(f2xy,'.\F7_2b.bmp');

fxy=double(f2xy);
Fuv=fft2(fxy);
FftShift=fftshift(Fuv);
AbsFftShift=abs(FftShift);
LogAbsFftShift=log(AbsFftShift);
subplot(2,3,3),imshow(LogAbsFftShift,[]),xlabel('(c) ����ͼ��ĸ���Ҷ�����׶���ͼ��'),colormap(gray),colorbar;

[N1,N2]=size(FftShift);
%��ֹƵ��D0=50ʱ���˲�Ч��
D0=50;
n1=fix(N1/2);
n2=fix(N2/2);
for i=1:N1
    for j=1:N2
        d=sqrt((i-n1)^2+(j-n2)^2);
        if (d<=D0)
            G(i,j)=FftShift(i,j);
        else
            G(i,j)=0;
        end
    end
end
G=ifftshift(G);
g=ifft2(G);
g=uint8(real(g));
subplot(2,3,4),imshow(g),xlabel('(d) �˲�ͼ��(\itD0=50)');
% imwrite(g,'.\F7_2d.bmp');

%��ֹƵ��D0=80ʱ���˲�Ч��
D0=80;
n1=fix(N1/2);
n2=fix(N2/2);
for i=1:N1
    for j=1:N2
        d=sqrt((i-n1)^2+(j-n2)^2);
        if (d<=D0)
            G(i,j)=FftShift(i,j);
        else
            G(i,j)=0;
        end
    end
end
G=ifftshift(G);
g=ifft2(G);
g=uint8(real(g));
subplot(2,3,6),imshow(g),xlabel('(e) �˲�ͼ��(\itD0=80)');
% imwrite(g,'.\F7_2e.bmp');
